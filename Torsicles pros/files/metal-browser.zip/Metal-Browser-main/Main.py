import sys
import json
import os
import urllib.request
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineUrlRequestInterceptor, QWebEngineProfile


from MSearch import Ui_MainWindow as SearchWindow
from MHistory import Ui_MainWindow as HistoryWindow
from MSettings import Ui_MainWindow as SettingsWindow

HISTORY_FILE = "history.json"

class AdBlockerInterceptor(QWebEngineUrlRequestInterceptor):
    def __init__(self):
        super().__init__()
        self.enabled = True
        self.blocked_domains = set()
        self.load_blocklist()

    def load_blocklist(self):
        """Fetches a public blocklist of ads and trackers from an online source"""
        try:
            blocklist_url = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
            print("Downloading ad-blocker list...")
            req = urllib.request.urlopen(blocklist_url)
            for line in req:
                decoded_line = line.decode('utf-8').strip()
                if decoded_line and not decoded_line.startswith('#'):
                    parts = decoded_line.split()
                    if len(parts) >= 2 and parts[0] in ('0.0.0.0', '127.0.0.1'):
                        self.blocked_domains.add(parts[1])
            print(f"Loaded {len(self.blocked_domains)} blocked domains successfully!")
        except Exception as e:
            print(f"Could not download blocklist, using fallback. Error: {e}")
            self.blocked_domains = {"doubleclick.net", "googleadservices.com", "googlesyndication.com"}

    def interceptRequest(self, info):
        if not self.enabled:
            return
        url_string = info.requestUrl().host()
        if url_string in self.blocked_domains:
            info.block(True)

class SettingsWindowApp(QMainWindow):
    def __init__(self, interceptor):
        super().__init__()
        self.ui = SettingsWindow()
        self.ui.setupUi(self)
        self.interceptor = interceptor
        self.ui.checkBox.setChecked(self.interceptor.enabled)
        self.ui.checkBox.stateChanged.connect(self.toggle_ad_blocker)

    def toggle_ad_blocker(self, state):
        self.interceptor.enabled = (state == 2)

class HistoryWindowApp(QMainWindow):
    def __init__(self, history_list):
        super().__init__()
        self.ui = HistoryWindow()
        self.ui.setupUi(self)
        history_text = "<br>".join(history_list)
        self.ui.textBrowser.setHtml(f"<h3>Saved History:</h3><p>{history_text}</p>")

class BrowserApp(QMainWindow):
    def __init__(self, interceptor):
        super().__init__()
        self.ui = SearchWindow()
        self.ui.setupUi(self)
        
        self.interceptor = interceptor
        self.history_list = self.load_history_from_json()
        
        self.history_win = None
        self.settings_win = None

      
        self.ui.tabWidget.setTabsClosable(True)
        self.ui.tabWidget.tabCloseRequested.connect(self.close_tab)
        

        self.ui.tabWidget.clear()
        self.add_new_tab("https://www.google.com", "Google")

        # Connect all your buttons and inputs
        self.ui.lineEdit.returnPressed.connect(self.load_webpage)
        self.ui.History.clicked.connect(self.open_history)
        self.ui.Settings.clicked.connect(self.open_settings)
        self.ui.pushButton.clicked.connect(self.go_back)
        self.ui.AddTab.clicked.connect(lambda: self.add_new_tab("https://www.google.com", "New Tab"))
        self.ui.Refresh.clicked.connect(self.refresh_page)

    def load_history_from_json(self):
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, "r") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return []
        return []

    def save_history_to_json(self):
        with open(HISTORY_FILE, "w") as f:
            json.dump(self.history_list, f, indent=4)

    def add_new_tab(self, url, title):
        """Creates a web engine view inside a new tab page"""
        browser = QWebEngineView()
        browser.setUrl(QUrl(url))
        
        tab_page = QWidget()
        layout = QVBoxLayout(tab_page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(browser)
        
        index = self.ui.tabWidget.addTab(tab_page, title)
        self.ui.tabWidget.setCurrentIndex(index)
        
        browser.urlChanged.connect(lambda qurl, b=browser: self.update_url_bar(b, qurl))
        browser.titleChanged.connect(lambda title, b=browser: self.update_tab_title(b, title))

    def close_tab(self, index):
        if self.ui.tabWidget.count() > 1:
            self.ui.tabWidget.removeTab(index)
        else:
            self.close()

    def update_url_bar(self, browser, qurl):
        current_page = self.ui.tabWidget.currentWidget()
        if current_page and browser in current_page.findChildren(QWebEngineView):
            self.ui.lineEdit.setText(qurl.toString())

    def update_tab_title(self, browser, title):
        for i in range(self.ui.tabWidget.count()):
            page = self.ui.tabWidget.widget(i)
            if page and browser in page.findChildren(QWebEngineView):
                short_title = (title[:12] + '..') if len(title) > 12 else title
                self.ui.tabWidget.setTabText(i, short_title)

    def load_webpage(self):
        url_text = self.ui.lineEdit.text()
        if not url_text.startswith("http://") and not url_text.startswith("https://"):
            url_text = "https://" + url_text
            
        if not self.history_list or self.history_list[-1] != url_text:
            self.history_list.append(url_text)
            self.save_history_to_json()
            
        current_page = self.ui.tabWidget.currentWidget()
        if current_page:
            browsers = current_page.findChildren(QWebEngineView)
            if browsers:
                browsers[0].setUrl(QUrl(url_text))

    def refresh_page(self):
        current_page = self.ui.tabWidget.currentWidget()
        if current_page:
            browsers = current_page.findChildren(QWebEngineView)
            if browsers:
                browsers[0].reload()

    def go_back(self):
        current_page = self.ui.tabWidget.currentWidget()
        if current_page:
            browsers = current_page.findChildren(QWebEngineView)
            if browsers:
                browsers[0].back()

    def open_history(self):
        self.history_list = self.load_history_from_json()
        self.history_win = HistoryWindowApp(self.history_list)
        self.history_win.show()

    def open_settings(self):
        if self.settings_win is None:
            self.settings_win = SettingsWindowApp(self.interceptor)
        self.settings_win.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)

    ad_blocker = AdBlockerInterceptor()
    profile = QWebEngineProfile.defaultProfile()
    profile.setUrlRequestInterceptor(ad_blocker)

    browser = BrowserApp(ad_blocker)
    browser.show()
    sys.exit(app.exec())