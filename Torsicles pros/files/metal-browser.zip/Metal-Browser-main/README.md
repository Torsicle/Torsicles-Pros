# Metal Browser 🔧

A lightweight Python-based web browser built with PySide6 (Qt for Python). Metal Browser is a proof-of-concept browser designed for educational and experimental purposes.

⚠️ **Warning:** Do not use Metal Browser as your default or main browser. It is not intended for production use as it is not yet stable or secure.

## Features

- **Tabbed Browsing** - Open multiple tabs and switch between them seamlessly
- **Ad Blocking** - Built-in ad blocker that uses the StevenBlack hosts blocklist to filter ads and trackers
- **Browse History** - Automatic history tracking saved to a JSON file
- **Settings** - Simple settings panel to toggle ad blocking on/off
- **Navigation Controls** - Back button and page refresh functionality
- **URL Bar** - Navigate to websites by typing URLs
- **Tab Management** - Close individual tabs or close the browser

## Requirements

- Python 3.7+
- PySide6 (Qt for Python)
- urllib (standard library)
- json (standard library)
- os (standard library)
- sys (standard library)

## Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/Aether-Group0/Metal-Browser.git
   cd Metal-Browser
   ```

2. **Install dependencies:**
   ```bash
   pip install PySide6
   ```

## Usage

Run the browser with:

```bash
python Main.py
```

The browser will open with a default Google homepage in the first tab. From there you can:

- Type URLs in the address bar and press Enter to navigate
- Click **Add Tab** to open new tabs
- Click **History** to view your browsing history
- Click **Settings** to toggle the ad blocker
- Click the back button to go to the previous page
- Click **Refresh** to reload the current page
- Click the X on a tab to close it

## Project Structure

```
Metal-Browser/
├── Main.py           # Main browser application and core logic
├── MSearch.py        # Search/main window UI
├── MHistory.py       # History window UI
├── MSettings.py      # Settings window UI
└── history.json      # Auto-generated browsing history file
```


### Images
<img width="797" height="613" alt="Metal Browser image2" src="https://github.com/user-attachments/assets/f4257556-e5ef-4762-a7a0-9299d79decdd" />


<img width="1122" height="785" alt="Metal Browser image1" src="https://github.com/user-attachments/assets/374473b9-e1d6-4d99-ab0a-4a5dc2f45f23" />




### Core Components

- **Main.py**
  - `AdBlockerInterceptor` - Intercepts web requests and blocks ads/trackers
  - `BrowserApp` - Main browser window with tab management
  - `HistoryWindowApp` - History display window
  - `SettingsWindowApp` - Settings panel for ad blocker control

- **MSearch.py** - UI for the main search/browser window
- **MHistory.py** - UI for the history viewer
- **MSettings.py** - UI for the settings window

## How the Ad Blocker Works

The ad blocker works by:

1. **Downloading a blocklist** - On startup, it downloads the StevenBlack hosts list from GitHub
2. **Parsing domains** - It extracts blocked domain names from the hosts file
3. **Intercepting requests** - Using Qt's `QWebEngineUrlRequestInterceptor`, it checks all web requests
4. **Blocking ads** - Requests to known ad/tracker domains are blocked
5. **Fallback mode** - If the blocklist can't be downloaded, it uses a hardcoded list of common ad networks

## History Tracking

Browsing history is automatically saved to `history.json` in the same directory. The history file stores URLs in JSON format:

```json
[
  "https://www.google.com",
  "https://www.github.com",
  "https://www.python.org"
]
```

## Known Limitations

- Not suitable for daily use or as a primary browser
- Limited security features compared to production browsers
- Performance may vary with large or complex websites
- No support for browser extensions
- Basic UI with limited customization options
- No built-in download manager
- No bookmarking system

## Future Improvements

Potential areas for enhancement:

- [ ] Improved security and stability
- [ ] Better performance optimization
- [ ] Bookmarking system
- [ ] Advanced settings
- [ ] Cookie and cache management
- [ ] Download manager
- [ ] Search engine selection
- [ ] Keyboard shortcuts
- [ ] Dark mode support

## License

This project is open-source. Feel free to fork, modify, and use for educational purposes.

## Contributing

Contributions are welcome! Feel free to:

- Report bugs and issues
- Suggest new features
- Submit pull requests with improvements
- Help improve documentation

## Support

For issues, questions, or suggestions, please open an issue on the [GitHub repository](https://github.com/Aether-Group0/Metal-Browser/issues).

---

**Made with ❤️ by Aether Group**
