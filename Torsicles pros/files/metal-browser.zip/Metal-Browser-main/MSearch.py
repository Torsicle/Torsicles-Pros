# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'SearchzLxvNB.ui'
##
## Created by: Qt User Interface Compiler version 6.11.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QLineEdit, QMainWindow,
    QPushButton, QSizePolicy, QStatusBar, QTabWidget,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1124, 754)
        icon = QIcon()
        iconThemeName = u"applications-system"
        if QIcon.hasThemeIcon(iconThemeName):
            icon = QIcon.fromTheme(iconThemeName)
        else:
            icon.addFile(u"../New Piskel-1.png.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)

        MainWindow.setWindowIcon(icon)
        MainWindow.setStyleSheet(u"QPushButton {\n"
"    background-color: #4A4A4A;\n"
"    color: #E2B4BD;\n"
"    border-radius: 5px;\n"
"    padding: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #524646;\n"
"    color: #F8B2B2;\n"
"    border-radius: 5px;\n"
"    padding: 10px;\n"
"}\n"
"\n"
"QMainWindow{\n"
"    background-color: #0F3040;\n"
"}\n"
"\n"
"QWebEngineView{\n"
"    background-color: #4A4A4A;\n"
"\n"
"}\n"
"\n"
"QLineEdit{\n"
"    background-color: #4A4A4A;\n"
"    color: #E2B4BD;\n"
"    border-radius: 5px;\n"
"    padding: 10px;\n"
"}\n"
"\n"
"QTabWidget{\n"
"  background-color: #4A4A4A;\n"
"    color: #E2B4BD;\n"
"    border-radius: 5px;\n"
"    padding: 10px;\n"
"}")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        icon1 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.GoPrevious))
        self.pushButton.setIcon(icon1)

        self.gridLayout.addWidget(self.pushButton, 0, 0, 1, 1)

        self.History = QPushButton(self.centralwidget)
        self.History.setObjectName(u"History")

        self.gridLayout.addWidget(self.History, 0, 1, 1, 1)

        self.Settings = QPushButton(self.centralwidget)
        self.Settings.setObjectName(u"Settings")

        self.gridLayout.addWidget(self.Settings, 0, 2, 1, 1)

        self.AddTab = QPushButton(self.centralwidget)
        self.AddTab.setObjectName(u"AddTab")
        icon2 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.ListAdd))
        self.AddTab.setIcon(icon2)

        self.gridLayout.addWidget(self.AddTab, 0, 3, 1, 1)

        self.Refresh = QPushButton(self.centralwidget)
        self.Refresh.setObjectName(u"Refresh")
        icon3 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.SystemReboot))
        self.Refresh.setIcon(icon3)

        self.gridLayout.addWidget(self.Refresh, 0, 4, 1, 1)

        self.lineEdit = QLineEdit(self.centralwidget)
        self.lineEdit.setObjectName(u"lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 0, 5, 1, 1)

        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.tabWidget.addTab(self.tab_2, "")

        self.gridLayout.addWidget(self.tabWidget, 1, 0, 1, 6)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Metal Browser", None))
        self.pushButton.setText("")
        self.History.setText(QCoreApplication.translate("MainWindow", u"History", None))
        self.Settings.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
        self.AddTab.setText("")
        self.Refresh.setText("")
        self.lineEdit.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Tab 1", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Tab 2", None))
    # retranslateUi

