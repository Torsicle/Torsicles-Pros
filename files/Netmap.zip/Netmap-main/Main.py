import sys
import webbrowser
import json

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QLabel,
    QVBoxLayout
)
from PySide6.QtCore import QObject, QThread, Signal, Slot

from ui_Netmap import Ui_MainWindow
from Get_INFO_Util import (
    get_network,
    get_router,
    get_arp_ips,
    Map
)


class ScanWorker(QObject):
    finished = Signal(object)
    error = Signal(str)

    @Slot()
    def run(self):
        try:
           
            network = get_network()
            router = get_router()
            ips = get_arp_ips()

            network_data = {
                "network": network,
                "router": router,
                "ips": ips
            }

           
            nmap_result = Map(router)

            network_data["nmap"] = nmap_result

            
            self.finished.emit(network_data)

        except Exception as e:
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)


        

        self.ui.textBrowser.setStyleSheet("""
            border: 1px solid #3a3a3a;
            border-radius: 8px;
            background-color: #2b2b2b;
            color: #ffffff;
            padding: 4px;
        """)



        self.ui.GithubLink.setStyleSheet("""
            border: 1px solid #3a3a3a;
            border-radius: 8px;
            background-color: #2b2b2b;
            color: #ffffff;
            padding: 4px;
        """)

        self.ui.MapStart.setStyleSheet("""
            border: 1px solid #3a3a3a;
            border-radius: 8px;
            background-color: #2b2b2b;
            color: #ffffff;
            padding: 4px;
        """)

        self.ui.pushButton.setStyleSheet("""
            border: 1px solid #3a3a3a;
            border-radius: 8px;
            background-color: #2b2b2b;
            color: #ffffff;
            padding: 4px;
        """)

        self.ui.GithubLink.clicked.connect(self.open_github_link)
        self.ui.MapStart.clicked.connect(self.Startmap)
        self.ui.pushButton.clicked.connect(self.close)

    def open_github_link(self):
        webbrowser.open(
            "https://aether-group0.github.io/About.Aether.Group/"
        )


    def Startmap(self):

        self.ui.MapStart.setEnabled(False)
        self.ui.MapStart.setText("Scanning...")

        self.thread = QThread()

       
        self.worker = ScanWorker()

    
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)

        
        self.worker.finished.connect(self.scan_finished)

       
        self.worker.error.connect(self.scan_error)

        
        self.worker.finished.connect(self.thread.quit)
        self.worker.error.connect(self.thread.quit)

        
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)

        
        self.thread.start()

    def scan_finished(self, network_data):
        try:
            
            with open("Data.json", "w", encoding="utf-8") as save:
                json.dump(network_data, save, indent=4)

            
            self.ui.textBrowser.setPlainText(
                json.dumps(network_data, indent=4)
            )

        except Exception as e:
            self.ui.textBrowser.setPlainText(
                f"Error processing scan results:\n{e}"
            )

        finally:
            self.ui.MapStart.setEnabled(True)
            self.ui.MapStart.setText("Start Scan")

    def scan_error(self, message):
        self.ui.textBrowser.setPlainText(
            f"Scan error:\n{message}"
        )

        self.ui.MapStart.setEnabled(True)
        self.ui.MapStart.setText("Start Scan")


if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())