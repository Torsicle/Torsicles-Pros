import subprocess
import re


def get_network():
    result = subprocess.run(
        ["ipconfig"],
        capture_output=True,
        text=True
    )

    match = re.search(
        r"IPv4 Address[.\s]*:\s*(\d+\.\d+\.\d+\.\d+)",
        result.stdout
    )

    if not match:
        raise RuntimeError("Could not find your IPv4 address.")

    ip = match.group(1)
    parts = ip.split(".")

    return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"


def get_router():
    result = subprocess.run(
        ["route", "print", "-4"],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr or "Could not read the routing table."
        )

    match = re.search(
        r"^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+"
        r"(\d+\.\d+\.\d+\.\d+)",
        result.stdout,
        re.MULTILINE
    )

    if not match:
        raise RuntimeError(
            "Could not find your router/default gateway."
        )

    return match.group(1)


def get_arp_ips():
    result = subprocess.run(
        ["arp", "-a"],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr or "Could not read the ARP table."
        )

    ips = re.findall(
        r"\b\d{1,3}(?:\.\d{1,3}){3}\b",
        result.stdout
    )

    return list(dict.fromkeys(ips))


def Map(router):
    print(f"Scanning router {router}...")

    result = subprocess.run(
        [
            "nmap",
            "-sV",
            "-O",
            router
        ],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr or "Nmap returned an error."
        )

    return result.stdout