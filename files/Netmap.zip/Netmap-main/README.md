# Netmap

A lightweight GUI tool for mapping and discovering IPs on your network using Nmap.

## Overview

Netmap is a Python-based desktop application that provides an intuitive interface for network discovery and IP mapping. It automatically detects your network configuration and uses Nmap to perform detailed network scanning, presenting results in an easy-to-read format.

## Features

- **Automatic Network Detection**: Automatically identifies your IPv4 address and network range
- **Router Discovery**: Detects your default gateway/router IP
- **ARP Scanning**: Retrieves active IP addresses from the ARP table
- **Nmap Integration**: Performs service version detection (`-sV`) and OS detection (`-O`) on your router
- **GUI Interface**: Built with PySide6 for a clean, modern user interface
- **JSON Export**: Automatically saves scan results to `Data.json` for easy data access
- **Real-time Display**: Shows scan results and errors in a text browser within the application

## Requirements

- **Python 3.8+**
- **PySide6**: For the GUI framework
- **Nmap**: Required for network scanning (must be installed separately and added to PATH)

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/Aether-Group0/Netmap.git
cd Netmap
```

### 2. Install Python Dependencies

```bash
pip install PySide6
```

### 3. Install Nmap

**Windows:**
Download and install from [nmap.org](https://nmap.org/download.html)

**macOS:**
```bash
brew install nmap
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install nmap
```

**Linux (Fedora/RHEL):**
```bash
sudo dnf install nmap
```

## Usage

Run the application with:

```bash
python Main.py
```

### Application Interface

The Netmap window contains:

- **Start Scan Button**: Initiates network discovery and mapping
- **Stop Map Button**: Closes the application
- **Github Button**: Opens the Aether Group website
- **Text Display Area**: Shows scan results in JSON format

### How It Works

1. Click **"Start Scan"** to begin
2. The application will:
   - Extract your IPv4 address using `ipconfig` (Windows) or equivalent
   - Calculate your network range (e.g., 192.168.1.0/24)
   - Retrieve your router's IP from the routing table
   - Collect active IPs from the ARP table
   - Run Nmap on your router IP to detect services and OS
3. Results are displayed in the text area and saved to `Data.json`

## Output Format

Scan results are returned as JSON with the following structure:

```json
{
  "network": "192.168.1.0/24",
  "router": "192.168.1.1",
  "ips": ["192.168.1.1", "192.168.1.100", "192.168.1.105"],
  "nmap": "Nmap scan output here..."
}
```

## Project Structure

- **Main.py**: Core application logic and GUI event handling
- **ui_Netmap.py**: Qt Designer UI configuration (auto-generated)
- **Get_INFO_Util.py**: Network information gathering utilities
- **LICENSE**: MIT License

## File Descriptions

### Main.py
Handles the main application window, threading for non-blocking scans, and UI interactions.

### Get_INFO_Util.py
Contains utility functions for:
- `get_network()`: Extracts IPv4 and calculates network range
- `get_router()`: Retrieves the default gateway IP
- `get_arp_ips()`: Gets active IPs from the ARP table
- `Map(router)`: Runs Nmap scan on the specified IP

### ui_Netmap.py
Auto-generated PySide6 UI code. Contains the visual layout and styling.

## Limitations

- **Windows-Specific**: Currently uses Windows-specific commands (`ipconfig`, `route print`, `arp -a`)
- **Root/Admin Required**: Network scanning with Nmap typically requires elevated privileges
- **Dependencies**: Requires Nmap to be installed and accessible from command line

## Troubleshooting

### "Could not find your IPv4 address"
Ensure your network is properly configured and `ipconfig` returns valid results.

### "Could not find your router/default gateway"
Check your network configuration and routing table.

### "Nmap returned an error"
Ensure Nmap is installed and added to your system PATH. On Windows, you may need to run the application as Administrator.

## Future Improvements

- Cross-platform support (Linux/macOS detection commands)
- Custom scan options and target selection
- Network visualization
- Export results in multiple formats
- Persistent scan history

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Author

Created by the Aether Group team.

For more information, visit: [Aether Group](https://aether-group0.github.io/About.Aether.Group/)

---

**Note**: Netmap is designed for network administration and educational purposes. Use responsibly and only on networks you own or have permission to scan.
